#include <stdbool.h>
#include <ostream>
#include <string>


#ifndef ELEMENT_H
#define ELEMENT_H


class Element {
    bool isDouble = true;
    double value = 0;

    bool TokenIsDouble(std::string const token);

    public:
        Element() {}
        
        Element(int value) {
            this->value = value;
            this->isDouble = false;
        }
        
        Element(double value) {
            this->value = value;
        }

        Element(const std::string& newVal);

        Element* Clone();

        virtual double Value() const;
        virtual int IntValue() const;
        virtual double DoubleValue() const;
        bool IsDouble() const;
        void ChangeType();
        void ChangeType(bool shouldBeDouble);
        void Value(double newVal);

        bool operator==(Element const &right) const;
        bool operator!=(Element const &right) const;
        friend std::ostream &operator<<(std::ostream &out, const Element &element);
        friend Element operator+(const Element &left, const Element &right);
        friend Element operator-(const Element &left, const Element &right);
        friend Element operator*(const Element &left, const Element &right);
        friend Element operator/(const Element &left, const Element &right);
        friend Element operator%(const Element &left, const Element &right);

        Element Calculate(Element right, std::string operation) const;
};

#endif